package CMS.Controller.Faculty;

import CMS.Controller.Login.LoginController;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

import java.io.File;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class MyProfileController implements Initializable {

    @FXML private Label nameLabel;
    @FXML private Label empIdLabel;
    @FXML private Label phoneLabel;
    @FXML private Label emailLabel;
    @FXML private Label genderLabel;
    @FXML private ImageView profileImageView;

    @FXML private Button changePasswordButton;
    @FXML private Pane passwordPane;
    @FXML private TextField newPassword;
    @FXML private TextField confirmPassword;

    private final String DB_URL = "jdbc:mysql://localhost:3306/College_Management";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "adminABHI";
    private String empId;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        empId = new LoginController().emp_id; // static session class to hold logged-in user
        loadProfileData();
    }

    private void loadProfileData() {
    if (empId == null || empId.isEmpty()) {
        System.out.println("No user logged in.");
        return;
    }

    String query = "SELECT * FROM faculty_info WHERE faculty_id = ?";

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
         PreparedStatement stmt = conn.prepareStatement(query)) {

        stmt.setString(1, empId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            String fullName = rs.getString("fname") + " " +
                              rs.getString("mname") + " " +
                              rs.getString("lname");

            nameLabel.setText("Hello..!! " + fullName.trim());
            empIdLabel.setText(rs.getString("faculty_id"));
            phoneLabel.setText(rs.getString("mobile"));
            emailLabel.setText(rs.getString("emailid"));
            genderLabel.setText(rs.getString("gender"));

            // Read image as blob
            Blob blob = rs.getBlob("profile_image");
            if (blob != null) {
                Image image = new Image(blob.getBinaryStream());
                profileImageView.setImage(image);
            } else {
                System.out.println("No profile image found.");
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    @FXML
    private void onChangePasswordClick() {
        passwordPane.setVisible(true);
        passwordPane.setManaged(true);
    }

    @FXML
    private void onUpdatePasswordClick() {
        String newPass = newPassword.getText().trim();
        String confirmPass = confirmPassword.getText().trim();

        if (newPass.isEmpty() || confirmPass.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Input Required", "Please enter both password fields.");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            showAlert(Alert.AlertType.ERROR, "Mismatch", "Passwords do not match.");
            return;
        }

        String updateQuery = "UPDATE faculty_info SET password = ? WHERE faculty_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(updateQuery)) {

            stmt.setString(1, newPass);
            stmt.setString(2, empId);

            int updated = stmt.executeUpdate();
            if (updated > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Password updated successfully.");
                passwordPane.setVisible(false);
                passwordPane.setManaged(false);
                newPassword.clear();
                confirmPassword.clear();
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update password.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "An error occurred while updating password.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
