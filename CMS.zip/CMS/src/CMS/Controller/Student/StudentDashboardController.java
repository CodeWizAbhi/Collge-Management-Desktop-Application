/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package CMS.Controller.Student;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author lohot
 */
public class StudentDashboardController{

    @FXML
    private Pane mainContainer;
    @FXML
    private Button MyProfileButton;
    @FXML
    private Button TimeTableButton;
    @FXML
    private Button MarksButton;
    @FXML
    private Button MaterialButton;
    @FXML
    private Button NoticeButton;
    @FXML
    private Pane contentPane;
    @FXML
    private Button logoutbutton;

    /**
     * Initializes the controller class.
     */
    @FXML
    void initialize() {
        loadUI("myProfile");
    }

    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Student/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Pane pane = FXMLLoader.load(fxmlUrl);
            contentPane.getChildren().clear();
            contentPane.getChildren().add(pane);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }
   

    @FXML
    private void handleMyProfile(ActionEvent event) {
    }

    @FXML
    private void handleTimeTable(ActionEvent event) {
    }

    @FXML
    private void handleMarks(ActionEvent event) {
    }

    @FXML
    private void handleMaterial(ActionEvent event) {
    }

    @FXML
    private void handleNotice(ActionEvent event) {
    }
    
    @FXML
    void handleLogOut(ActionEvent event) {
        try {
        // Load the Login.fxml from the Login package
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/CMS/FXML/Login/login.fxml"));
        Pane loginPane = loader.load();

        // Get current scene's stage from any component, e.g., logoutbutton
        javafx.stage.Stage stage = (javafx.stage.Stage) logoutbutton.getScene().getWindow();

        // Set the new scene
        javafx.scene.Scene scene = new javafx.scene.Scene(loginPane);
        stage.setScene(scene);
        stage.show();
    } catch (Exception e) {//////////
        System.out.println("Failed to load Login.fxml");
        e.printStackTrace();
    }
    
}

}