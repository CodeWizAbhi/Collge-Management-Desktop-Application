package CMS.Controller.Login;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LoginController {
    public static String emp_id;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button loginButton;

    @FXML
    private PasswordField passwordField;

    @FXML
    private AnchorPane rootPane;

    @FXML
    private TextField usernameField;

    @FXML
    void handleLoginAction(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Input Required", "Please enter username and password.");
            return;
        }

        String role = authenticateUser(username, password);

        if (role != null) {
            loadDashboard(role);
        } else {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid username or password.");
        }
    }

    @FXML
    void initialize() {
        assert loginButton != null : "fx:id=\"loginButton\" was not injected: check your FXML file 'login.fxml'.";
        assert passwordField != null : "fx:id=\"passwordField\" was not injected: check your FXML file 'login.fxml'.";
        assert rootPane != null : "fx:id=\"rootPane\" was not injected: check your FXML file 'login.fxml'.";
        assert usernameField != null : "fx:id=\"usernameField\" was not injected: check your FXML file 'login.fxml'.";
        usernameField.requestFocus();
        usernameField.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               passwordField.requestFocus();
          }
        });
        passwordField.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               loginButton.fire();
          }
        });
    }

    private Connection connectDB() {
        String url = "jdbc:mysql://localhost:3306/College_Management"; // Update as per your DB
        String user = "root"; // Your DB username
        String password = "adminABHI"; // Your DB password

        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Connection Error", "Failed to connect to the database.");
            return null;
        }
    }

    private String authenticateUser(String userId, String password) {
        String[][] roles = {
            {"admin", "emp_id"},
            {"faculty_info", "faculty_id"},
            {"students_info", "enrollmentno"}
        };

        String role = null;

        try (Connection conn = connectDB()) {
            if (conn == null) return null;

            for (String[] roleEntry : roles) {
                String table = roleEntry[0];
                String idColumn = roleEntry[1];

                String query = "SELECT * FROM " + table + " WHERE " + idColumn + " = ? AND password = ?";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, userId);
                    stmt.setString(2, password);

                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        role = table.equals("faculty_info") ? "faculty" :
                               table.equals("students_info") ? "student" : "admin";
                        emp_id = userId;
                        break;
                    }
                }
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error while checking credentials.");
        }

        return role;
    }

    private void loadDashboard(String role) {
        String fxmlFile;

        switch (role) {
            case "admin":
                fxmlFile = "/CMS/FXML/Admin/AdminDashboard.fxml";
                break;
            case "faculty":
                fxmlFile = "/CMS/FXML/Faculty/FacultyDashboard.fxml";
                break;
            case "student":
                fxmlFile = "/CMS/FXML/Student/StudentDashboard.fxml";
                break;
            default:
                showAlert(Alert.AlertType.ERROR, "Error", "Unknown user role.");
                return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            AnchorPane pane = loader.load();
            Scene scene = new Scene(pane);
            Stage stage = (Stage) rootPane.getScene().getWindow();
            stage.setTitle("College Management System - " + role.toUpperCase());
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            showAlert(Alert.AlertType.ERROR, "Loading Error", "Failed to load the dashboard.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
