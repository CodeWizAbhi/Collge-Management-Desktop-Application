package CMS.Controller.Admin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.scene.input.MouseEvent;

import java.io.*;
import java.sql.*;
import java.time.LocalDate;

public class editStudentController {

    @FXML private TextField empIdSearchField, enrollmentNoField, fnameField, mnameField, lnameField,
            emailField, mobileField, passwordField, guardianNameField, guardianContactField,
            nationalityField, aadharNumberField;
    @FXML private TextArea addressField;
    @FXML private MenuButton genderMenuButton, departmentMenuButton, menuYearButton, 
            menubloodgroupButton, categoryMenuButton;
    @FXML private DatePicker birthDatePicker, admissionDatePicker;
    @FXML private ImageView imageView;

    private File selectedImageFile;
    private String selectedGender, selectedDepartment, selectedYear, selectedBloodGroup, selectedCategory;

    // Connect DB
    private Connection connectDB() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");
    }

    // MenuItem click handlers
    @FXML public void initialize() {
        genderMenuButton.getItems().forEach(item -> item.setOnAction(e -> {
            selectedGender = item.getText();
            genderMenuButton.setText(selectedGender);
        }));

        departmentMenuButton.getItems().forEach(item -> item.setOnAction(e -> {
            selectedDepartment = item.getText();
            departmentMenuButton.setText(selectedDepartment);
        }));

        menuYearButton.getItems().forEach(item -> item.setOnAction(e -> {
            selectedYear = item.getText();
            menuYearButton.setText(selectedYear);
        }));

        menubloodgroupButton.getItems().forEach(item -> item.setOnAction(e -> {
            selectedBloodGroup = item.getText();
            menubloodgroupButton.setText(selectedBloodGroup);
        }));

        categoryMenuButton.getItems().forEach(item -> item.setOnAction(e -> {
            selectedCategory = item.getText();
            categoryMenuButton.setText(selectedCategory);
        }));
    }

    @FXML
    private void searchStudent(MouseEvent event) {
        String enrollment = empIdSearchField.getText();

        String query = "SELECT * FROM students_info WHERE enrollmentno = ?";
        try (Connection conn = connectDB(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, enrollment);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                enrollmentNoField.setText(rs.getString("enrollmentno"));
                fnameField.setText(rs.getString("fname"));
                mnameField.setText(rs.getString("mname"));
                lnameField.setText(rs.getString("lname"));
                emailField.setText(rs.getString("emailid"));
                mobileField.setText(rs.getString("mobile"));
                passwordField.setText(rs.getString("password"));
                birthDatePicker.setValue(rs.getDate("birthdate").toLocalDate());
                admissionDatePicker.setValue(rs.getDate("admission_date").toLocalDate());
                addressField.setText(rs.getString("address"));
                guardianNameField.setText(rs.getString("guardian_name"));
                guardianContactField.setText(rs.getString("guardian_contact"));
                nationalityField.setText(rs.getString("nationality"));
                aadharNumberField.setText(rs.getString("aadhar_number"));

                selectedGender = rs.getString("gender");
                genderMenuButton.setText(selectedGender);

                selectedDepartment = rs.getString("department");
                departmentMenuButton.setText(selectedDepartment);

                selectedYear = rs.getString("year");
                menuYearButton.setText(selectedYear);

                selectedBloodGroup = rs.getString("blood_group");
                menubloodgroupButton.setText(selectedBloodGroup);

                selectedCategory = rs.getString("category");
                categoryMenuButton.setText(selectedCategory);

                Blob imageBlob = rs.getBlob("profile_image");
                if (imageBlob != null) {
                    Image image = new Image(imageBlob.getBinaryStream());
                    imageView.setImage(image);
                }

            } else {
                showAlert(Alert.AlertType.ERROR, "No student found with this enrollment number.");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void uploadProfilePhoto(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Image File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        selectedImageFile = fileChooser.showOpenDialog(null);

        if (selectedImageFile != null) {
            Image image = new Image(selectedImageFile.toURI().toString());
            imageView.setImage(image);
        }
    }

    @FXML
    private void updateStudent(ActionEvent event) {
        String query = "UPDATE students_info SET fname=?, mname=?, lname=?, department=?, year=?, emailid=?, mobile=?, birthdate=?, address=?, password=?, gender=?, admission_date=?, guardian_name=?, guardian_contact=?, blood_group=?, nationality=?, category=?, aadhar_number=?, profile_image=? WHERE enrollmentno=?";

        try (Connection conn = connectDB(); PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, fnameField.getText());
            stmt.setString(2, mnameField.getText());
            stmt.setString(3, lnameField.getText());
            stmt.setString(4, selectedDepartment);
            stmt.setString(5, selectedYear);
            stmt.setString(6, emailField.getText());
            stmt.setString(7, mobileField.getText());
            stmt.setDate(8, Date.valueOf(birthDatePicker.getValue()));
            stmt.setString(9, addressField.getText());
            stmt.setString(10, passwordField.getText());
            stmt.setString(11, selectedGender);
            stmt.setDate(12, Date.valueOf(admissionDatePicker.getValue()));
            stmt.setString(13, guardianNameField.getText());
            stmt.setString(14, guardianContactField.getText());
            stmt.setString(15, selectedBloodGroup);
            stmt.setString(16, nationalityField.getText());
            stmt.setString(17, selectedCategory);
            stmt.setString(18, aadharNumberField.getText());

            // Convert image to input stream
            if (selectedImageFile != null) {
                FileInputStream fis = new FileInputStream(selectedImageFile);
                stmt.setBinaryStream(19, fis, (int) selectedImageFile.length());
            } else {
                stmt.setNull(19, Types.BLOB);
            }

            stmt.setString(20, enrollmentNoField.getText());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Student updated successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Failed to update student.");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setContentText(message);
        alert.show();
    }
}
