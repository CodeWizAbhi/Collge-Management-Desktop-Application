package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.Desktop;
import java.io.*;
import java.sql.*;

public class addNoticeController {

    @FXML private TextField txtTitle;
    @FXML private TextArea txtDescription;
    @FXML private Button btnChoosePDF;
    @FXML private Button btnUploadNotice;
    @FXML private Button btnViewPDF;
    @FXML private Label lblPDFName;

    private File selectedPDF;

    @FXML
    public void handleChoosePDF() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Notice PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        selectedPDF = fileChooser.showOpenDialog(new Stage());

        if (selectedPDF != null) {
            lblPDFName.setText(selectedPDF.getName());
        } else {
            lblPDFName.setText("No file selected");
        }
    }

    @FXML
    public void handleUploadNotice() {
        String title = txtTitle.getText();
        String description = txtDescription.getText();

        if (title.isEmpty() || description.isEmpty() || selectedPDF == null) {
            lblPDFName.setText("Fill all fields & choose PDF");
            return;
        }

        String url = "jdbc:mysql://localhost:3306/College_Management";
        String user = "root";
        String pass = "adminABHI";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             FileInputStream fis = new FileInputStream(selectedPDF)) {

            String sql = "INSERT INTO notices (title, description, notice_pdf) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, description);
            pstmt.setBinaryStream(3, fis, (int) selectedPDF.length());

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                lblPDFName.setText("Notice uploaded successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            lblPDFName.setText("Upload failed.");
        }
    }
}
