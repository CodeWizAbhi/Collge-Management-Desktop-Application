package CMS.Controller.Admin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class BranchController {

    @FXML
    private Button addBranchButton;

    @FXML
    private Button viewBranchButton;

    @FXML
    private Pane mainContentPane;
    
    @FXML
    void initialize() {
    	loadUI("addBranch");
    }
    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Pane pane = FXMLLoader.load(fxmlUrl);
            mainContentPane.getChildren().clear();
            mainContentPane.getChildren().add(pane);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }

    @FXML
    void handleAddBranch(ActionEvent event) {
    	loadUI("addBranch");
    }

    @FXML
    void handleViewBranch(ActionEvent event) {
    	loadUI("viewBranch");
    }

}


