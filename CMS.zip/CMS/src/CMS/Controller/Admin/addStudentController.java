package CMS.Controller.Admin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileInputStream;
import java.sql.*;
import java.time.LocalDate;

public class addStudentController {

    @FXML private TextField txtfname, txtmname, txtlname, txtenrollno, txtemail, txtmobile, txtaadhar, txtnationality, txtguardianName, txtguardianContact;
    @FXML private PasswordField txtpassword;
    @FXML private TextArea txtaddr;
    @FXML private DatePicker birthdatePicker, admissiondatePicker;
    @FXML private MenuButton menuGenderButton, menuDepartmentButton, menuYearButton, menuCategoryButton, menubloodgroupButton;
    @FXML private ImageView imageView;

    private String selectedGender = "";
    private String selectedDepartment = "";
    private String selectedYear = "";
    private String selectedCategory = "";
    private String selectedBloodGroup = "";
    private File selectedImageFile;

    // ========== Gender ==========
    @FXML private void handleMaleRadio(ActionEvent event) {
        selectedGender = "Male";
        menuGenderButton.setText("Male");
    }

    @FXML private void handleFemaleRadio(ActionEvent event) {
        selectedGender = "Female";
        menuGenderButton.setText("Female");
    }

    // ========== Department ==========
    @FXML private void handleCORadio() { setDepartment("CO"); }
    @FXML private void handleIFRadio() { setDepartment("IF"); }
    @FXML private void handleENTCRadio() { setDepartment("ENTC"); }
    @FXML private void handleEERadio() { setDepartment("EE"); }
    @FXML private void handleCERadio() { setDepartment("CE"); }
    @FXML private void handleMERadio() { setDepartment("ME"); }
    @FXML private void handleAERadio() { setDepartment("AE"); }

    private void setDepartment(String dept) {
        selectedDepartment = dept;
        menuDepartmentButton.setText(dept);
    }

    // ========== Year ==========
    @FXML private void handleFYradio() { setYear("FY"); }
    @FXML private void handleSYradio() { setYear("SY"); }
    @FXML private void handleTYradio() { setYear("TY"); }

    private void setYear(String year) {
        selectedYear = year;
        menuYearButton.setText(year);
    }

    // ========== Blood Group ==========
    @FXML private void handleApositiveradio() { setBloodGroup("A+"); }
    @FXML private void handleAnegativeradio() { setBloodGroup("A-"); }
    @FXML private void handlerBpositiveradio() { setBloodGroup("B+"); }
    @FXML private void handlerBnegativeradio() { setBloodGroup("B-"); }
    @FXML private void handleABpositiveradio() { setBloodGroup("AB+"); }
    @FXML private void handleABnegativeradio() { setBloodGroup("AB-"); }
    @FXML private void handlerOpositiveradio() { setBloodGroup("O+"); }
    @FXML private void handlerOnegativeradio() { setBloodGroup("O-"); }

    private void setBloodGroup(String bg) {
        selectedBloodGroup = bg;
        menubloodgroupButton.setText(bg);
    }

    // ========== Category ==========
    @FXML private void handleOpenradio() { setCategory("Open"); }
    @FXML private void handleOBCradio() { setCategory("OBC"); }
    @FXML private void handlerSCradio() { setCategory("SC"); }
    @FXML private void handlerSTradio() { setCategory("ST"); }
    @FXML private void handleVJNTradio() { setCategory("VJNT"); }
    @FXML private void handleEWSradio() { setCategory("EWS"); }

    private void setCategory(String cat) {
        selectedCategory = cat;
        menuCategoryButton.setText(cat);
    }

    // ========== Upload Image ==========
    @FXML
    private void handleUploadButton(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Profile Image");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        selectedImageFile = fileChooser.showOpenDialog(null);
        if (selectedImageFile != null) {
            Image image = new Image(selectedImageFile.toURI().toString());
            imageView.setImage(image);
        }
    }

    // ========== Add Student ==========
    @FXML
    private void HandleAddStudent(ActionEvent event) {
        String sql = "INSERT INTO students_info (enrollmentno, fname, mname, lname, department, year, emailid, mobile, birthdate, address, password, gender, admission_date, guardian_name, guardian_contact, blood_group, nationality, category, aadhar_number, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");
             PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, txtenrollno.getText());
            pst.setString(2, txtfname.getText());
            pst.setString(3, txtmname.getText());
            pst.setString(4, txtlname.getText());
            pst.setString(5, selectedDepartment);
            pst.setString(6, selectedYear);
            pst.setString(7, txtemail.getText());
            pst.setString(8, txtmobile.getText());
            pst.setDate(9, Date.valueOf(birthdatePicker.getValue()));
            pst.setString(10, txtaddr.getText());
            pst.setString(11, txtpassword.getText());
            pst.setString(12, selectedGender);
            pst.setDate(13, Date.valueOf(admissiondatePicker.getValue()));
            pst.setString(14, txtguardianName.getText());
            pst.setString(15, txtguardianContact.getText());
            pst.setString(16, selectedBloodGroup);
            pst.setString(17, txtnationality.getText());
            pst.setString(18, selectedCategory);
            pst.setString(19, txtaadhar.getText());

            // For image
             if (selectedImageFile != null) {
                FileInputStream fis = new FileInputStream(selectedImageFile);
                pst.setBinaryStream(20, fis, (int) selectedImageFile.length());
            } else {
                pst.setNull(20, Types.BLOB);
            }


            pst.executeUpdate();
            showAlert(Alert.AlertType.INFORMATION, "Student Added Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setTitle("Student Registration");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
