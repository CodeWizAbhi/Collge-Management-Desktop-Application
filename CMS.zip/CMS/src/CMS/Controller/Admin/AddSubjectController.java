package CMS.Controller.Admin;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class AddSubjectController implements Initializable {

    @FXML
    private TextField subjectNameField;

    @FXML
    private TextField subjectCodeField;

    @FXML
    private Button addSubjectButton;

    private final String DB_URL = "jdbc:mysql://localhost:3306/College_Management";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "adminABHI";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        addSubjectButton.setOnAction(this::handleAddBranch);
    }

    private void handleAddBranch(ActionEvent event) {
        String subjectName = subjectNameField.getText();
        String subjectCode = subjectCodeField.getText();

        if (subjectName.isEmpty() || subjectCode.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Please fill in all fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO subject (subject_name, subject_code) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, subjectName);
            stmt.setString(2, subjectCode);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Subject added successfully!");
                subjectNameField.clear();
                subjectCodeField.clear();
            } else {
                showAlert(Alert.AlertType.ERROR, "Failed to add subject.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database error: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType alertType, String message) {
        Alert alert = new Alert(alertType);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
