package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;

public class ViewEditAdminController {

    @FXML private TextField empIdSearchField;
    @FXML private TextField fnameField;
    @FXML private TextField mnameField;
    @FXML private TextField lnameField;
    @FXML private TextField emailField;
    @FXML private TextField phoneField;
    @FXML private TextField genderField;

    private String dbUrl = "jdbc:mysql://localhost:3306/College_Management";
    private String dbUser = "root";
    private String dbPassword = "adminABHI";

    @FXML
    void handleSearch() {
        String empId = empIdSearchField.getText();
        if (empId.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Validation Error", "Please enter Employee ID");
            return;
        }

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM admin WHERE emp_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, empId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                fnameField.setText(rs.getString("first_name"));
                mnameField.setText(rs.getString("middle_name"));
                lnameField.setText(rs.getString("last_name"));
                emailField.setText(rs.getString("email"));
                phoneField.setText(rs.getString("phone_number"));
                genderField.setText(rs.getString("gender"));
            } else {
                showAlert(Alert.AlertType.INFORMATION, "Not Found", "No employee found with ID: " + empId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error fetching data from database.");
        }
    }

    @FXML
    void handleUpdate() {
        String empId = empIdSearchField.getText();
        String fname = fnameField.getText();
        String mname = mnameField.getText();
        String lname = lnameField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String gender = genderField.getText();

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String updateQuery = "UPDATE admin SET first_name=?, middle_name=?, last_name=?, email=?, phone_number=?, gender=? WHERE emp_id=?";
            PreparedStatement stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, fname);
            stmt.setString(2, mname);
            stmt.setString(3, lname);
            stmt.setString(4, email);
            stmt.setString(5, phone);
            stmt.setString(6, gender);
            stmt.setString(7, empId);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Employee data updated successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Update failed. Check employee ID.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Error updating data.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
