package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Alert;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ShowSubjectsController implements Initializable {

    @FXML
    private VBox subjectsContainer;

    private final String DB_URL = "jdbc:mysql://localhost:3306/College_Management";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "adminABHI";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadSubjects();
    }

    private void loadSubjects() {
        subjectsContainer.getChildren().clear();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM subject";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("subject_name");
                String code = rs.getString("subject_code");

                HBox subjectRow = createSubjectRow(id, name, code);
                subjectsContainer.getChildren().add(subjectRow);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load subjects: " + e.getMessage());
        }
    }

    private HBox createSubjectRow(int id, String name, String code) {
        Label nameLabel = new Label("Subject Name: " + name);
        nameLabel.setPrefWidth(300);
        nameLabel.setStyle("-fx-font-size: 15px; -fx-font-style: Bold; -fx-text-fill: red;");
        Label codeLabel = new Label("Subject Code: " + code);
        codeLabel.setPrefWidth(200);
        codeLabel.setStyle("-fx-font-size: 15px; -fx-font-style: Bold; -fx-text-fill: red;");
        ImageView deleteIcon = new ImageView(new Image(getClass().getResource("/images/delete.png").toExternalForm()));
        deleteIcon.setFitWidth(30);
        deleteIcon.setFitHeight(30);

        Button deleteBtn = new Button();
        deleteBtn.setGraphic(deleteIcon);
        deleteBtn.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        deleteBtn.setOnAction(e -> deleteSubject(id));

        HBox row = new HBox(20, nameLabel, codeLabel, deleteBtn);
        row.setStyle("-fx-padding: 10; -fx-border-color: black; -fx-border-radius: 5;");
        return row;
    }

    private void deleteSubject(int id) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String deleteQuery = "DELETE FROM subject WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(deleteQuery);
            stmt.setInt(1, id);
            int result = stmt.executeUpdate();

            if (result > 0) {
                showAlert("Success", "Subject deleted successfully.");
                loadSubjects(); // Refresh UI
            } else {
                showAlert("Error", "Failed to delete subject.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Database error: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
