package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import javafx.scene.input.KeyCode;




public class addFacultyController {

    @FXML private TextField txtfname, txtmname, txtlname, txtemail, txtmobile, txtexperience, txtfacultyId;
    @FXML private PasswordField txtpassword;
    @FXML private MenuButton menuGenderButton, menuDepartmentButton, menuPostButton;
    @FXML private DatePicker joiningDatePicker;
    @FXML private ImageView imageView;
    @FXML private Button btnupload, btnAddFaculty;


    private String selectedGender = "";
    private String selectedDepartment = "";
    private String selectedPost = "";
    private File selectedImageFile;

    @FXML
    public void initialize() {
    // Move focus from firstName to middleName
    txtfname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtmname.requestFocus();
        }
    });

    // Move focus from middleName to lastName
    txtmname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtlname.requestFocus();
        }
    });
    txtlname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtfacultyId.requestFocus();
        }
    });
    txtfacultyId.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            menuDepartmentButton.requestFocus();
        }
    });
    menuDepartmentButton.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            menuGenderButton.requestFocus();
        }
    });
    menuGenderButton.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtemail.requestFocus();
       }
    });
    txtemail.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtmobile.requestFocus();
       }
    });
    txtmobile.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtpassword.requestFocus();
       }
    });
    txtpassword.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               txtexperience.requestFocus();
          }
    });
    txtexperience.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               menuPostButton.requestFocus();
          }
    });
    menuPostButton.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               joiningDatePicker.requestFocus();
          }
    });
    joiningDatePicker.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               btnupload.fire();
          }
    });
    btnupload.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               btnAddFaculty.fire();
          }
    });
   
     
    
    
}
    // === Gender Handlers ===
    @FXML private void handleMaleRadio() { selectedGender = "Male"; menuGenderButton.setText("Male"); }
    @FXML private void handleFemaleRadio() { selectedGender = "Female"; menuGenderButton.setText("Female"); }
    @FXML private void handleOtherRadio() { selectedGender = "Other"; menuGenderButton.setText("Other"); }

    // === Department Handlers ===
    @FXML private void handleCORadio() { selectedDepartment = "CO"; menuDepartmentButton.setText("CO"); }
    @FXML private void handleIFRadio() { selectedDepartment = "IF"; menuDepartmentButton.setText("IF"); }
    @FXML private void handleEERadio() { selectedDepartment = "EE"; menuDepartmentButton.setText("EE"); }
    @FXML private void handleEJRadio() { selectedDepartment = "EJ"; menuDepartmentButton.setText("EJ"); }
    @FXML private void handleMERadio() { selectedDepartment = "ME"; menuDepartmentButton.setText("ME"); }
    @FXML private void handleAERadio() { selectedDepartment = "AE"; menuDepartmentButton.setText("AE"); }
    @FXML private void handleCERadio() { selectedDepartment = "CE"; menuDepartmentButton.setText("CE"); }

    // === Post Handlers ===
    @FXML private void handleFacultyRadio() { selectedPost = "Faculty"; menuPostButton.setText("Faculty"); }
    @FXML private void handleHODRadio() { selectedPost = "HOD"; menuPostButton.setText("HOD"); }

    // === Upload Image ===
    @FXML private void handleUploadButton() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose Profile Image");
        selectedImageFile = fileChooser.showOpenDialog(null);
        if (selectedImageFile != null) {
            imageView.setImage(new Image(selectedImageFile.toURI().toString()));
        }
    }

    // === Add Faculty to Database ===
    @FXML private void handleAddFaculty() {
        String fname = txtfname.getText();
        String mname = txtmname.getText();
        String lname = txtlname.getText();
        String fid = txtfacultyId.getText();
        String email = txtemail.getText();
        String mobile = txtmobile.getText();
        String experience = txtexperience.getText();
        String password = txtpassword.getText();
        LocalDate joiningDate = joiningDatePicker.getValue();

        String query = "INSERT INTO faculty_info (faculty_id, fname, mname, lname, department, emailid, mobile, " +
                "experience_years, post, password, gender, joining_date, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, fid);
            pstmt.setString(2, fname);
            pstmt.setString(3, mname);
            pstmt.setString(4, lname);
            pstmt.setString(5, selectedDepartment);
            pstmt.setString(6, email);
            pstmt.setString(7, mobile);
            pstmt.setInt(8, Integer.parseInt(experience));
            pstmt.setString(9, selectedPost);
            pstmt.setString(10, password);
            pstmt.setString(11, selectedGender);
            pstmt.setDate(12, Date.valueOf(joiningDate));

            if (selectedImageFile != null) {
                FileInputStream fis = new FileInputStream(selectedImageFile);
                pstmt.setBinaryStream(13, fis, (int) selectedImageFile.length());
            } else {
                pstmt.setNull(13, Types.BLOB);
            }

            int rows = pstmt.executeUpdate();
            showAlert(rows > 0 ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR,
                      rows > 0 ? "Faculty Added Successfully!" : "Failed to Add Faculty!");

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setTitle("Message");
        alert.setContentText(message);
        alert.show();
    }
}
