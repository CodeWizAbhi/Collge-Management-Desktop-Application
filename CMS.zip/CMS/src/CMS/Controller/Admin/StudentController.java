package CMS.Controller.Admin;

import java.net.URL;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;

public class StudentController {

    @FXML
    private Button addStudentButton;

    @FXML
    private Button editStudentButton;

    @FXML
    private ScrollPane mainContentPane;

    @FXML
    void initialize() {
        loadUI("addStudent");
    }

    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Parent root = FXMLLoader.load(fxmlUrl);
            mainContentPane.setContent(root);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }

    @FXML
    void handleAddStudent(ActionEvent event) {
        loadUI("addStudent");
    }

    @FXML
    void handleEditStudent(ActionEvent event) {
        loadUI("editStudent");
    }
}
