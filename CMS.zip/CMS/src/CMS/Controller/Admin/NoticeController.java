package CMS.Controller.Admin;

import java.net.URL;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class NoticeController {

    @FXML
    private Button addNoticeButton;

    @FXML
    private Pane mainContentPane;

    @FXML
    private Button viewNoticeButton;
    
    @FXML
    void initialize() {
    	loadUI("addNotice");
    }
    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Pane pane = FXMLLoader.load(fxmlUrl);
            mainContentPane.getChildren().clear();
            mainContentPane.getChildren().add(pane);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }


    @FXML
    void handleAdd(ActionEvent event) {
        loadUI("addNotice");
    }

    @FXML
    void handleView(ActionEvent event) {
        loadUI("viewNotice");
    }

}
