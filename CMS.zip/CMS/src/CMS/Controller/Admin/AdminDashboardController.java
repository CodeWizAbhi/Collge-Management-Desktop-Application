package CMS.Controller.Admin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.Pane;
import javafx.scene.control.Button;

public class AdminDashboardController {

    @FXML private Button profileButton;
    @FXML private Button studentButton;
    @FXML private Button facultyButton;
    @FXML private Button branchButton;
    @FXML private Button noticeButton;
    @FXML private Button subjectsButton;
    @FXML private Button adminsButton;
    @FXML private Pane contentPane;
    @FXML
    private Button logoutbutton;

    @FXML
    void initialize() {
        loadUI("Profile");
    }

    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Pane pane = FXMLLoader.load(fxmlUrl);
            contentPane.getChildren().clear();
            contentPane.getChildren().add(pane);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }

    @FXML void handleProfile(ActionEvent event) { loadUI("Profile"); }
    @FXML void handleStudent(ActionEvent event) { loadUI("Student"); }
    @FXML void handleFaculty(ActionEvent event) { loadUI("Faculty"); }
    @FXML void handleBranch(ActionEvent event) { loadUI("Branch"); }
    @FXML void handleNotice(ActionEvent event) { loadUI("Notice"); }
    @FXML void handleSubjects(ActionEvent event) { loadUI("Subjects"); }
    @FXML void handleAdmins(ActionEvent event) { loadUI("Admins"); }
    @FXML
    void handleLogOut(ActionEvent event) {
        try {
        // Load the Login.fxml from the Login package
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/CMS/FXML/Login/login.fxml"));
        Pane loginPane = loader.load();

        // Get current scene's stage from any component, e.g., logoutbutton
        javafx.stage.Stage stage = (javafx.stage.Stage) logoutbutton.getScene().getWindow();

        // Set the new scene
        javafx.scene.Scene scene = new javafx.scene.Scene(loginPane);
        stage.setScene(scene);
        stage.show();
    } catch (Exception e) {//////////
        System.out.println("Failed to load Login.fxml");
        e.printStackTrace();
    }
    }}
