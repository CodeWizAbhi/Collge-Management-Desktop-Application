package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.Alert;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ViewBranchController implements Initializable {

    @FXML
    private VBox branchContainer;

    private final String DB_URL = "jdbc:mysql://localhost:3306/College_Management";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "adminABHI";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadBranchs();
    }

    private void loadBranchs() {
        branchContainer.getChildren().clear();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM branch";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("branch_name");

                HBox BranchRow = createBranchRow(id, name);
                branchContainer.getChildren().add(BranchRow);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load branch: " + e.getMessage());
        }
    }

    private HBox createBranchRow(int id, String name) {
        Label nameLabel = new Label(name);
        nameLabel.setPrefWidth(600);
        nameLabel.setStyle("-fx-font-size: 20px; -fx-font-style: Bold; -fx-text-fill: red; ");        
        ImageView deleteIcon = new ImageView(new Image(getClass().getResource("/images/delete.png").toExternalForm()));
        deleteIcon.setFitWidth(30);
        deleteIcon.setFitHeight(30);

        Button deleteBtn = new Button();
        deleteBtn.setGraphic(deleteIcon);
        deleteBtn.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        deleteBtn.setOnAction(e -> deleteSubject(id));

        HBox row = new HBox(20, nameLabel, deleteBtn);
        row.setStyle("-fx-padding: 10; -fx-border-color: black; -fx-border-radius: 5;");
        return row;
    }

    private void deleteSubject(int id) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String deleteQuery = "DELETE FROM branch WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(deleteQuery);
            stmt.setInt(1, id);
            int result = stmt.executeUpdate();

            if (result > 0) {
                showAlert("Success", "Branch deleted successfully.");
                loadBranchs(); // Refresh UI
            } else {
                showAlert("Error", "Failed to delete Branch.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Database error: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
