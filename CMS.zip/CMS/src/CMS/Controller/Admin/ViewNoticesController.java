package CMS.Controller.Admin;

import java.awt.Desktop;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import javafx.geometry.Pos;

public class ViewNoticesController {

    @FXML private ListView<HBox> noticeListView;

    @FXML
    public void initialize() {
        loadNoticesFromDatabase();
    }

    private void loadNoticesFromDatabase() {
        String url = "jdbc:mysql://localhost:3306/College_Management";
        String user = "root";
        String pass = "adminABHI";

        String query = "SELECT id, title, description, notice_pdf FROM notices ORDER BY id DESC";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ObservableList<HBox> noticeItems = FXCollections.observableArrayList();

            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String description = rs.getString("description");
                byte[] pdfData = rs.getBytes("notice_pdf");

                HBox hBox = createNoticeItem(title, description, id, pdfData);
                noticeItems.add(hBox);
            }

            noticeListView.setItems(noticeItems);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private HBox createNoticeItem(String title, String description, int id, byte[] pdfData) {
        HBox hBox = new HBox(10);
        hBox.setAlignment(Pos.CENTER_LEFT);
        hBox.setStyle("-fx-padding: 15px; -fx-border-color: red; -fx-border-radius: 8px;");

        Text titleText = new Text(title);
        titleText.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Text descriptionText = new Text(description);
        descriptionText.setStyle("-fx-font-size: 14px;");

        Button viewPDFButton = new Button("View PDF");
        viewPDFButton.setStyle("-fx-background-color: transparent; -fx-text-fill: black; -fx-padding: 10px; -fx-border-color: black; -fx-border-radius: 8px; -fx-cursor: hand;");
        viewPDFButton.setOnAction(event -> viewPDF(id, pdfData));

        hBox.getChildren().addAll(titleText, descriptionText, viewPDFButton);
        return hBox;
    }

    private void viewPDF(int id, byte[] pdfData) {
        // Save the PDF data to a temporary file
        try {
            File tempFile = File.createTempFile("notice_" + id, ".pdf");
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(pdfData);
            }

            // Open the PDF in the default viewer
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(tempFile);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to open the PDF");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
