package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import javafx.scene.input.KeyCode;

public class EditFacultyController {

    @FXML private TextField txtSearchFacultyId, txtfname, txtlname, txtmname, txtfacultyId, txtemail, txtmobile, txtpassword, txtexperience;
    @FXML private MenuButton menuDepartmentButton, menuGenderButton, menuPostButton;
    @FXML private DatePicker joiningDatePicker;
    @FXML private ImageView imageView;
    @FXML private Button btnupload;
    private File selectedImageFile;
    private String selectedDepartment, selectedGender, selectedPost;
    
    @FXML
    public void initialize() {
    // Move focus from firstName to middleName
    txtfname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtmname.requestFocus();
        }
    });

    // Move focus from middleName to lastName
    txtmname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtlname.requestFocus();
        }
    });
    txtlname.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            txtfacultyId.requestFocus();
        }
    });
    txtfacultyId.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            menuDepartmentButton.requestFocus();
        }
    });
    menuDepartmentButton.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            menuGenderButton.requestFocus();
        }
    });
    menuGenderButton.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtemail.requestFocus();
       }
    });
    txtemail.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtmobile.requestFocus();
       }
    });
    txtmobile.setOnKeyPressed(event -> {
       if (event.getCode() == KeyCode.ENTER) {
            txtpassword.requestFocus();
       }
    });
    txtpassword.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               txtexperience.requestFocus();
          }
    });
    txtexperience.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               menuPostButton.requestFocus();
          }
    });
    menuPostButton.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               joiningDatePicker.requestFocus();
          }
    });
    joiningDatePicker.setOnKeyPressed(event -> {
          if (event.getCode() == KeyCode.ENTER) {
               btnupload.fire();
          }
    });
   
     
    
    
}

    // === Department selection handlers ===
    @FXML private void handleCORadio() { menuDepartmentButton.setText("CO"); selectedDepartment = "CO"; }
    @FXML private void handleIFRadio() { menuDepartmentButton.setText("IF"); selectedDepartment = "IF"; }
    @FXML private void handleEERadio() { menuDepartmentButton.setText("EE"); selectedDepartment = "EE"; }
    @FXML private void handleEJRadio() { menuDepartmentButton.setText("EJ"); selectedDepartment = "EJ"; }
    @FXML private void handleMERadio() { menuDepartmentButton.setText("ME"); selectedDepartment = "ME"; }
    @FXML private void handleAERadio() { menuDepartmentButton.setText("AE"); selectedDepartment = "AE"; }
    @FXML private void handleCERadio() { menuDepartmentButton.setText("CE"); selectedDepartment = "CE"; }

    // === Gender selection handlers ===
    @FXML private void handleMaleRadio() { menuGenderButton.setText("Male"); selectedGender = "Male"; }
    @FXML private void handleFemaleRadio() { menuGenderButton.setText("Female"); selectedGender = "Female"; }
    @FXML private void handleOtherRadio() { menuGenderButton.setText("Other"); selectedGender = "Other"; }

    // === Post selection handlers ===
    @FXML private void handleFacultyRadio() { menuPostButton.setText("Faculty"); selectedPost = "Faculty"; }
    @FXML private void handleHODRadio() { menuPostButton.setText("HOD"); selectedPost = "HOD"; }

    @FXML
    private void handleSearchFaculty() {
        String facultyId = txtSearchFacultyId.getText();
        if (facultyId.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Input", "Please enter a Faculty ID to search.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM faculty_info WHERE faculty_id = ?")) {

            stmt.setString(1, facultyId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                txtfname.setText(rs.getString("fname"));
                txtmname.setText(rs.getString("mname"));
                txtlname.setText(rs.getString("lname"));
                txtfacultyId.setText(rs.getString("faculty_id"));
                txtemail.setText(rs.getString("emailid"));
                txtmobile.setText(rs.getString("mobile"));
                txtpassword.setText(rs.getString("password"));
                txtexperience.setText(rs.getString("experience_years"));

                selectedDepartment = rs.getString("department");
                selectedGender = rs.getString("gender");
                selectedPost = rs.getString("post");

                menuDepartmentButton.setText(selectedDepartment);
                menuGenderButton.setText(selectedGender);
                menuPostButton.setText(selectedPost);

                Date joinDate = rs.getDate("joining_date");
                if (joinDate != null) {
                    joiningDatePicker.setValue(joinDate.toLocalDate());
                }

                Blob imageBlob = rs.getBlob("profile_image");
                if (imageBlob != null) {
                    InputStream is = imageBlob.getBinaryStream();
                    imageView.setImage(new Image(is));
                }

            } else {
                showAlert(Alert.AlertType.ERROR, "Not Found", "Faculty ID not found in the database.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to fetch faculty data.");
        }
    }

    @FXML
    private void handleUploadButton() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Choose Image");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.jpg", "*.png", "*.jpeg"));
        selectedImageFile = chooser.showOpenDialog(null);
        if (selectedImageFile != null) {
            imageView.setImage(new Image(selectedImageFile.toURI().toString()));
        } else {
            showAlert(Alert.AlertType.WARNING, "No File Selected", "Please select an image file.");
        }
    }

    @FXML
    private void handleEditFaculty() {
        if (!validateFields()) {
            showAlert(Alert.AlertType.WARNING, "Incomplete Form", "Please fill in all required fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE faculty_info SET fname=?, mname=?, lname=?, emailid=?, mobile=?, password=?, department=?, gender=?, experience_years=?, post=?, joining_date=?, profile_image=? WHERE faculty_id=?")) {

            stmt.setString(1, txtfname.getText());
            stmt.setString(2, txtmname.getText());
            stmt.setString(3, txtlname.getText());
            stmt.setString(4, txtemail.getText());
            stmt.setString(5, txtmobile.getText());
            stmt.setString(6, txtpassword.getText());
            stmt.setString(7, selectedDepartment);
            stmt.setString(8, selectedGender);
            stmt.setString(9, txtexperience.getText());
            stmt.setString(10, selectedPost);
            stmt.setDate(11, Date.valueOf(joiningDatePicker.getValue()));

            if (selectedImageFile != null) {
                FileInputStream fis = new FileInputStream(selectedImageFile);
                stmt.setBinaryStream(12, fis, (int) selectedImageFile.length());
            } else {
                stmt.setNull(12, Types.BLOB);
            }

            stmt.setString(13, txtfacultyId.getText());

            int updated = stmt.executeUpdate();
            if (updated > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Faculty information updated successfully.");
            } else {
                showAlert(Alert.AlertType.WARNING, "Update Failed", "No rows were updated.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to update faculty information.");
        }
    }

    private boolean validateFields() {
        return !txtfacultyId.getText().isEmpty() &&
                !txtfname.getText().isEmpty() &&
                !txtlname.getText().isEmpty() &&
                !txtemail.getText().isEmpty() &&
                !txtmobile.getText().isEmpty() &&
                !txtpassword.getText().isEmpty() &&
                !txtexperience.getText().isEmpty() &&
                selectedDepartment != null &&
                selectedGender != null &&
                selectedPost != null &&
                joiningDatePicker.getValue() != null;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
