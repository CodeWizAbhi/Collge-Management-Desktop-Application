package CMS.Controller.Admin;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;

public class FacultyController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button addFacultyButton;

    @FXML
    private Button editFacultyButton;

    @FXML
    private ScrollPane mainContentPane;

    @FXML
    void handleAddFaculty(ActionEvent event) {
               loadUI("addFaculty");
    }

    @FXML
    void handleEditFaculty(ActionEvent event) {
               loadUI("editFaculty");

    }

    @FXML
    void initialize() {
               loadUI("addFaculty");
    }
     private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Parent root = FXMLLoader.load(fxmlUrl);
            mainContentPane.setContent(root);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }

}
