package CMS.Controller.Admin;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AddAdminController {

    @FXML private ResourceBundle resources;
    @FXML private URL location;
    @FXML private ToggleGroup GENDER;
    @FXML private Button addAdminButton;
    @FXML private TextField emailField;
    @FXML private TextField empIdField;
    @FXML private MenuItem femaleradio;
    @FXML private TextField fnameField;
    @FXML private Button handleChooseFile;
    @FXML private TextField lnameField;
    @FXML private MenuItem maleradio;
    @FXML private MenuButton menuGenderButton;
    @FXML private TextField mnameField;
    @FXML private TextField phnoField;
    @FXML private PasswordField passwordField;

    private Stage stage;
    public File selectedFile;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    void HandleAddAdmin(ActionEvent event) {
        String Email = emailField.getText();
        String EmpId = empIdField.getText();
        String Gender = menuGenderButton.getText();
        String Lname = lnameField.getText();
        String Mname = mnameField.getText();
        String Fname = fnameField.getText();
        String PhNo = phnoField.getText();
        String Password = passwordField.getText();
        String profilePath = selectedFile != null ? selectedFile.getAbsolutePath() : "";

        // Validate inputs
        if (Email.isEmpty() || EmpId.isEmpty() || Gender.equals("--select--") || Lname.isEmpty() ||
            Mname.isEmpty() || Fname.isEmpty() || PhNo.isEmpty() || profilePath.isEmpty() || Password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Fields", "Please enter all credentials and upload a profile picture.");
            return;
        }

        // Insert into database
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/College_Management", "root", "adminABHI");

            String sql = "INSERT INTO admin (emp_id, first_name, middle_name, last_name, email, phone_number, gender, profile_image_path, password) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, EmpId);
            pstmt.setString(2, Fname);
            pstmt.setString(3, Mname);
            pstmt.setString(4, Lname);
            pstmt.setString(5, Email);
            pstmt.setString(6, PhNo);
            pstmt.setString(7, Gender);
            pstmt.setString(8, profilePath);
            pstmt.setString(9, Password);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Admin added successfully.");
                clearFields();
            } else {
                showAlert(Alert.AlertType.ERROR, "Failure", "Failed to add admin.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Could not insert data. See console for details.");
        }
    }

    @FXML
    void HandleDialog(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Profile Picture");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );

        selectedFile = fileChooser.showOpenDialog(stage);
    }

    @FXML
    void HandleFemaleRadio(ActionEvent event) {
        menuGenderButton.setText("Female");
    }

    @FXML
    void handleMaleRadio(ActionEvent event) {
        menuGenderButton.setText("Male");
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void clearFields() {
        fnameField.clear();
        mnameField.clear();
        lnameField.clear();
        empIdField.clear();
        emailField.clear();
        phnoField.clear();
        passwordField.clear();
        menuGenderButton.setText("--select--");
        selectedFile = null;
    }

    @FXML
    void initialize() {
        assert GENDER != null : "fx:id=\"GENDER\" was not injected: check your FXML file 'addAdmin.fxml'.";
        assert passwordField != null : "fx:id=\"passwordField\" was not injected: check your FXML file.";
    }
}
