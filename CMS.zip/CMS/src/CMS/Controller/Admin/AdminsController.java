package CMS.Controller.Admin;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.net.URL;
import javafx.event.ActionEvent;

public class AdminsController {

    @FXML
    private Pane mainContentPane;
    @FXML
    void initialize() {
    	loadUI("addAdmin");
    }
    private void loadUI(String fileName) {
        try {
            URL fxmlUrl = getClass().getResource("/CMS/FXML/Admin/" + fileName + ".fxml");
            System.out.println("Trying to load: " + fxmlUrl);
            if (fxmlUrl == null) {
                System.out.println("FXML file not found!");
                return;
            }
            Pane pane = FXMLLoader.load(fxmlUrl);
            mainContentPane.getChildren().clear();
            mainContentPane.getChildren().add(pane);
        } catch (Exception e) {
            System.out.println("Error loading FXML: " + fileName);
            e.printStackTrace();
        }
    }

    @FXML
    void handleAddAdmin(ActionEvent event) {
    	loadUI("addAdmin");
    }

    @FXML
    void handleEditAdmin(ActionEvent event) {
    	loadUI("editAdmin");
    }
}
