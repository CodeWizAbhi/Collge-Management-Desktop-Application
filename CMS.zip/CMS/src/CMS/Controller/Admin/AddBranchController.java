package CMS.Controller.Admin;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class AddBranchController implements Initializable {

    @FXML
    private TextField BranchNameField;
    @FXML
    private Button addBranchButton;

    private final String DB_URL = "jdbc:mysql://localhost:3306/College_Management"; // Change this
    private final String DB_USER = "root"; // Change this
    private final String DB_PASSWORD = "adminABHI"; // Change this

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Optional: pre-load stuff
    }

    @FXML
    private void handleAddBranch(ActionEvent event) {
        String branchName = BranchNameField.getText().trim();

        if (branchName.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Branch name cannot be empty.");
            return;
        }

        try {
            // Load driver (optional from Java 6+, but safe to include)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to DB
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Insert query
            String query = "INSERT INTO branch (branch_name) VALUES (?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, branchName);

            int rowsInserted = pstmt.executeUpdate();

            if (rowsInserted > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Branch added successfully!");
                BranchNameField.clear();
            } else {
                showAlert(Alert.AlertType.ERROR, "Failed", "Could not add branch.");
            }

            pstmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
