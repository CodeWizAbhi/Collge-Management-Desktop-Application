package CMS.Controller.Splash;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;

public class SplashScreenController {

    @FXML
    private AnchorPane rootPane;

    @FXML
    private ProgressIndicator progressIndicator;

    @FXML
    private Label lblLoading;

    @FXML
    private ImageView imageView;

    public void initialize() {
        PauseTransition delay = new PauseTransition(Duration.seconds(5)); // Splash screen delay
        delay.setOnFinished(event -> loadLoginScreen());
        delay.play();
    }

    private void loadLoginScreen() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/CMS/FXML/Login/login.fxml"));
            AnchorPane loginPane = loader.load();

            // Get the current stage (window)
            Stage stage = (Stage) rootPane.getScene().getWindow();

            // Set the new scene
            Scene scene = new Scene(loginPane);
            stage.setScene(scene);
            stage.setTitle("Login - College Management System");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
