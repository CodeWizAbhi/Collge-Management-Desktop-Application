#------Create database first------#

CREATE DATABASE college_management;

#------Use Database------#

USE college_management;

#------Create Table Admin------#

CREATE TABLE admin (
    emp_id VARCHAR(50) PRIMARY KEY,
    first_name VARCHAR(50),
    middle_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    phone_number VARCHAR(15),
    gender VARCHAR(10),
    profile_image_path TEXT,
    password VARCHAR(100) NOT NULL
);

#------Insert data for one user in admin table ------#

INSERT INTO admin (
    emp_id,
    first_name,
    middle_name,
    last_name,
    email,
    phone_number,
    gender,
    profile_image_path,
    password
)
VALUES (
    'EMP2022',
    'Abhishek',
    'Santosh',
    'Lohot',
    'lohotabhishek16@gmail.com',
    '9373644863',
    'Male',
    null,
    'abhi@2007'
);

#------Create Table Faculty Info------#

CREATE TABLE faculty_info (
    faculty_id VARCHAR(20) PRIMARY KEY,
    fname VARCHAR(50),
    mname VARCHAR(50),
    lname VARCHAR(50),
    department ENUM('CO', 'IF', 'EE', 'EJ', 'ME', 'AE', 'CE'),
    emailid VARCHAR(100),
    mobile VARCHAR(15),
    experience_years INT,
    post ENUM('Faculty', 'HOD'),
    password VARCHAR(255),
    gender ENUM('Male', 'Female', 'Other'),
    joining_date DATE,
    profile_image LONGBLOB
);

#------Create Table Student Info------#

CREATE TABLE students_info (
    enrollmentno       VARCHAR(20) PRIMARY KEY,
    fname              VARCHAR(50),
    mname              VARCHAR(50),
    lname              VARCHAR(50),
    department         ENUM('IF', 'CO', 'ENTC', 'EE', 'CE', 'ME', 'AE'),
    year               VARCHAR(2),
    emailid            VARCHAR(100),
    mobile             VARCHAR(15),
    birthdate          DATE,
    address            TEXT,
    password           VARCHAR(255),
    gender             ENUM('Male', 'Female'),
    admission_date     DATE,
    guardian_name      VARCHAR(100),
    guardian_contact   VARCHAR(15),
    blood_group        ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
    nationality        VARCHAR(50),
    category           ENUM('Open', 'OBC', 'SC', 'ST', 'VJNT', 'EWS'),
    aadhar_number      VARCHAR(12),
    profile_image	   LONGBLOB
);

#------Create Table Subject ------#

CREATE TABLE subject (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(50) NOT NULL UNIQUE
);

#------Create Table Branch------#

CREATE TABLE branch (
    id INT AUTO_INCREMENT PRIMARY KEY,
    branch_name VARCHAR(100) NOT NULL UNIQUE
);

#------Create Table Notices------#

CREATE TABLE notices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    description TEXT,
    notice_pdf LONGBLOB
);
#->>Now you can run the application and login with admin Employee Id and Password

