package CMS;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class CMSMain extends Application {

    @Override
    public void start(Stage stage) {
        try {
            // Load Splash Screen first
            Parent root = FXMLLoader.load(getClass().getResource("/CMS/FXML/Splash/SplashScreen.fxml"));

            // Create a scene and set it on the stage
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setMaximized(true); // Open in fullscreen mode
            stage.setTitle("College Management System");

            // Load the application icon
            Image icon = new Image(getClass().getResourceAsStream("/Images/mortarboard.png"));
            stage.getIcons().add(icon);

            // Show the stage
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading the FXML file.");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
